﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ConsoRestWebService
{
    
    internal class Program
    {
        static void Main(string[] args)
        {
            var url = "https://reqres.in/api/users?/2";
            var httpRequest = (HttpWebRequest)HttpWebRequest.Create(url);
            httpRequest.Method = "GET";
            httpRequest.ContentType = "application/json";
            var httpResponse = (HttpWebResponse)httpRequest.GetResponse();
            //httpResponse.ContentType = "application/json";
            using (var streamReader = new System.IO.StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
            Console.WriteLine(result);
            
            }
            Console.WriteLine( httpResponse.StatusCode );
            Console.ReadKey();
        }
    }
}
